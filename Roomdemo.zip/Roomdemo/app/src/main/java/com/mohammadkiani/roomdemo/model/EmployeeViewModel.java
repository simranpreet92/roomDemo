package com.mohammadkiani.roomdemo.model;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.mohammadkiani.roomdemo.data.EmployeeRepository;

import java.util.List;

public class EmployeeViewModel extends AndroidViewModel {
    private EmployeeRepository repository;
    private final LiveData<List<Employee>> allEmployee;

    public EmployeeViewModel(@NonNull Application application) {
        super(application);
        repository = new EmployeeRepository(application);
        allEmployee = repository.getAllEmployees();

    }

    public LiveData<List<Employee>> getAllEmployee(){return allEmployee;}
    public LiveData<Employee> getEmployee(int id) {return repository.getEmployee(id);}
    public void insert(Employee employee){repository.insert(employee);}
    public  void update(Employee employee){repository.update(employee);}
    public  void delete(Employee employee){repository.delete(employee);}

}
