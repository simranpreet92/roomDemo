package com.mohammadkiani.roomdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.mohammadkiani.roomdemo.model.Employee;
import com.mohammadkiani.roomdemo.model.EmployeeViewModel;

import java.util.Arrays;

public class AddEmployeeActivity extends AppCompatActivity {

    private EditText etName , etSalary ;
    private Spinner spinnerDept;

    private Boolean isEditing = false;
    private  int employeeId = 0;
    private  Employee employeeToBeUpdated;
    private EmployeeViewModel employeeViewModel;

    public static final String NAME_REPLY = "name_reply";

    public static final String SALARY_REPLY = "salary_reply";

    public static final String DEPARTMENT_REPLY = "department_reply";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_employee);

        // instantiate EmployeeViewModel
        employeeViewModel = new ViewModelProvider.AndroidViewModelFactory(this.getApplication())
                .create(EmployeeViewModel.class);
        etName = findViewById(R.id.et_name);
        etSalary = findViewById(R.id.et_salary);
        spinnerDept = findViewById(R.id.spinner_dept);

        Button addUpdateButton = findViewById(R.id.btn_add_employee);
        addUpdateButton.setOnClickListener( v ->
        {
            addUpdateButton();
        });

        if(getIntent().hasCategory(MainActivity.EMPLOYEE_ID))
        {
            employeeId = getIntent().getIntExtra(MainActivity .EMPLOYEE_ID , 0);
            employeeViewModel.getEmployee(employeeId).observe(this ,employee -> {
                if(employee != null)
                {
                    etName.setText(employee.getName());
                    etSalary.setText(String.valueOf(employee.getSalary()));
                    String[] departmentArray = getResources().getStringArray(R.array.departments);
                    int position = Arrays.asList(departmentArray).indexOf(employee.getDepartmentname());
                    spinnerDept.setSelection(position);
                    employeeToBeUpdated = employee;
                }
            });
            TextView label = findViewById(R.id.label);
            isEditing = true;
            label.setText(R.string.update_label);
            addUpdateButton.setText(R.string.update_employee_btn_text);

        }
    }

    private void addUpdateButton() {
        String name = etName.getText().toString().trim();
        String salary = etSalary.getText().toString().trim();
        String department = spinnerDept.getSelectedItem().toString().trim();

        if(name.isEmpty())
        {
            etName.setError("name field cannot be empty");
            etName.requestFocus();
            return;
        }

        if(salary.isEmpty())
        {
            etSalary.setError("salary field cannot be empty");
            etSalary.requestFocus();
            return;
        }

        if(isEditing){
            Employee employee = new Employee();
            employee.setId(employeeId);
            employee.setName(name);
            employee.setDepartmentname(department);
            employee.setJoiningDate(employeeToBeUpdated.getJoiningDate());
            employee.setSalary(Double.parseDouble(salary));
            employeeViewModel.update(employee);
        }
        else
        {
            Intent replyIntent  = new Intent( );
            replyIntent.putExtra(NAME_REPLY,name);
            replyIntent.putExtra(DEPARTMENT_REPLY ,department);
            replyIntent.putExtra(SALARY_REPLY, salary);
            //set result
            setResult(RESULT_OK , replyIntent);
            Toast.makeText(this, "Employee_Added", Toast.LENGTH_SHORT).show();
        }
        finish();
    }
}