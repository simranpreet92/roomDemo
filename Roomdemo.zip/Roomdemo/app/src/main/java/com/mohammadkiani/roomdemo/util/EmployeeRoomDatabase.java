package com.mohammadkiani.roomdemo.util;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.mohammadkiani.roomdemo.data.EmployeeDao;
import com.mohammadkiani.roomdemo.model.Employee;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Employee.class}, version  =1 , exportSchema = false)
public abstract class  EmployeeRoomDatabase extends RoomDatabase {

    private static final String DB_NAME = "room_employee_database";

    public abstract EmployeeDao employeeDao();

    private static volatile EmployeeRoomDatabase INSTANCE;

    private static final int NUMBER_OF_THREADS = 4;
    // execute service that help us to do background threads

    public  static final ExecutorService databaseWriteExecutor
    = Executors . newFixedThreadPool(NUMBER_OF_THREADS);

    public static EmployeeRoomDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            synchronized (EmployeeRoomDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), EmployeeRoomDatabase.class, DB_NAME)
                            .addCallback(sRoomdatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;

    }

//when data is ready ,backgrounds threads are performed
private static final RoomDatabase.Callback sRoomdatabaseCallback =
 new RoomDatabase.Callback()
 {
     @Override
     public void onCreate(@NonNull SupportSQLiteDatabase db) {
         super.onCreate(db);

         databaseWriteExecutor.execute(()->
         {
             EmployeeDao employeeDao = INSTANCE.employeeDao();
             employeeDao.deleteAll();
         });
     }
 };

}
