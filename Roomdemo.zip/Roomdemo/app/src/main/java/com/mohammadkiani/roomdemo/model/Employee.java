package com.mohammadkiani.roomdemo.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import java.lang.reflect.Constructor;

// this is our entity in room db
@Entity(tableName = "employee")
public class Employee<constructor> {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id ;

    @ColumnInfo(name = "name")
    @NonNull
    private String name ;

    @ColumnInfo(name = "department")
    private String departmentname;

    @ColumnInfo(name = "joining_date")
    private String joiningDate;

    @ColumnInfo(name = "salary")
    private double salary;

    @Ignore
    public Employee()
    {}

    public Employee (@NonNull String name , String departmentname , String joiningDate , double salary)
    {
        this.name = name;
        this.departmentname = departmentname;
        this.joiningDate = joiningDate;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    @NonNull
    public String getName() {
        return name;
    }

    public String getDepartmentname() {
        return departmentname;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public double getSalary() {
        return salary;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(@NonNull String name) {
        this.name = name;
    }

    public void setDepartmentname(String departmentname) {
        this.departmentname = departmentname;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    
}
