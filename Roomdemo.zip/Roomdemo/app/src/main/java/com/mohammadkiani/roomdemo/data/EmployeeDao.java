package com.mohammadkiani.roomdemo.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.mohammadkiani.roomdemo.model.Employee;

import java.util.List;

@Dao
public interface EmployeeDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert (Employee employee);

    @Query("DELETE FROM employee")
    void deleteAll();

    @Query("SELECT * FROM employee ORDER BY name ASC")
    LiveData<List<Employee>> getALlEmployee();

   @Query("SELECT * FROM employee WHERE id == :id")
    LiveData<Employee> getEmployee(int id);

   @Update
  void update(Employee employee);

   @Delete
   void delete (Employee employee);
}
